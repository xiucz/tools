#include<iostream>
#include<string>
using namespace std;

int filter_adapter( string& id1, string& seq1, string& id2, string& seq2);