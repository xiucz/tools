#include <string>
#include <iostream>
#include <fstream>
using namespace std;
int filter_small_size( string &seq1, string &seq2 );
